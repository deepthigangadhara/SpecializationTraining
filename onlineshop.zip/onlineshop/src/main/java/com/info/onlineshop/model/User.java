package com.info.onlineshop.model;

public class User {
    
}
