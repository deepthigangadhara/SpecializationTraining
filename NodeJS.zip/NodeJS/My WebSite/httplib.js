const http=require('http');
const fs=require('fs');
http.createServer((req,res)=>{
    if(req.url==='/home'|| req.url==='/'){
        let data=fs.readFileSync('My WebSite/templates/index.html');
        res.write(data);

    }else if(req.url==='/signin'){
        let data=fs.readFileSync('My WebSite/templates/signin.html');
        res.write(data);

    }
    else if(req.url==='/signup'){
        let data=fs.readFileSync('My WebSite/templates/signup.html');
        res.write(data);

    }
    else if(req.url==='/grocery'){
        let data=fs.readFileSync('My WebSite/templates/grocery.html');
        res.write(data);

    }
    else if(req.url==='/mobile'){
        let data=fs.readFileSync('My WebSite/templates/mobiles.html');
        res.write(data);

    }
    else if(req.url==='/electronics'){
        let data=fs.readFileSync('My WebSite/templates/electronics.html');
        res.write(data);

    }else if(req.url==='/cart'){
        let data=fs.readFileSync('My WebSite/templates/cart.html');
        res.write(data);

    }
    else{
        let data=fs.readFileSync('Static/error.html');
        res.write(data);

    }
    res.end();

    
}).listen(8080,()=>{console.log('Server Started at port 8080')});