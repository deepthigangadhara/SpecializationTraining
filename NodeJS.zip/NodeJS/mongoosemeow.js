
const m= require('mongoose');
meowmeow().catch((err)=>console.log(err));
async function meowmeow(){
    await m.connect('mongodb+srv://admin:deepthig2000@cluster0.pyjx7.mongodb.net/myFirstDatabase?retryWrites=true&w=majority');
    const meowS=m.Schema({
        _id:Number,
        name:String,
        breed:String,
        Star:Number
    });
    const meowModel=m.model('meow', meowS);
    const doc=new meowModel();
    doc._id=1;
    doc.name='Billo Rani';
    doc.breed='Persian Cat';
    doc.star=5;

    await doc.save();
}