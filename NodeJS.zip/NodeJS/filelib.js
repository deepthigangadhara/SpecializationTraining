const fs=require('fs');
/*fs.readFile('meow1.txt', (err, data)=>{
    if(err===null){
        console.log(data.toString())
    }else{
       // console.log(err);
       console.log(err.message);
    }
})*/
/*fs.readFile('meow.txt', (err, data)=>
err===null ? console.log(data.toString()) : console.log(err.message),
);*/
let d=fs.readFileSync('meow.txt');
fs.writeFile('meow.txt', d.toString()+' Hello', (err)=>{
    if(err===null){
        console.log('Successfully write Data!');
    }else{
        console.log(err.message);
    }
});