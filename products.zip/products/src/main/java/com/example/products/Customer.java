package com.example.products;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Customer {
   
    String name;
    String address;
    String phone;
    String email;
    String password;
   
    
}
