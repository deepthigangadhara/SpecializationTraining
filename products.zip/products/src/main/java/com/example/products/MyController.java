package com.example.products;

import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class MyController {
    List<Product> list=new ArrayList<>();
    List<Customer> cust=new ArrayList<>();

    @GetMapping("/hello")
    public String hello(){
        return "Hello";
    }
    @PostMapping("/addProduct")
    public List<Product> addP(@RequestBody Product p){
        list.add(p);
        return list;
    }
    @GetMapping("/getProduct")
    public List<Product> getProduct(){ 
          return list;
    }
    @PostMapping("/addCustomer")
    public List<Customer>addCustomer(@RequestBody Customer c){
        cust.add(c);
        return cust;      
    }
    @GetMapping("/getCustomer")
    public List<Customer> getCustomer(){
        return cust;
    }
    @GetMapping("/getProduct/{id}")
    public Product getByID(@PathVariable int id){
        for(Product p:list){
            if(p.id==id)
             return p;
        }
        return null;
    }
}
