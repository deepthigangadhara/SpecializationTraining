var stud1={
    roll:101,
    name : 'Deepthi',
    age :21,
    marks:{
        phy : 56,
        chem: 44,
        math: 67
    }

}
var stud2={
    ...stud1,
    marks: {
        ...stud1.marks
    }
}
console.log(stud1)
console.log(stud2)
stud2.marks.chem=100
console.log(stud2)
console.log(stud1)