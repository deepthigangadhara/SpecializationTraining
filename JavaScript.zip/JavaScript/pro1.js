function fun1(){
    console.log("Good Morning..")
    console.log("Fun1 Executed")
}
function hello(ob){
    return function(){
        console.log("Alchemy Solutions")
        ob()
        console.log("Hello Everyone")
    }
}
var a=hello(fun1)
a()