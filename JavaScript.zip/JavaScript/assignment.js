class student{
    constructor(roll, name, age){
        this.roll=roll;
        this.name=name;
        this.age=age;

    }
}
class CS extends student{
    constructor(roll, name, age,marks){
        super(roll, name, age)
        this.marks=marks;
    }
    //var marks={}
    show(){
        console.log(this.marks)
    }
}
class IT extends student{
    constructor(roll, name, age,marks){
        super(roll, name, age)
        this.marks=marks;
    }
    show(){
        console.log(this.marks)
    }
}
 
var ob1=new CS(101, 'vikas', 25, {aws: 50, ml: 70, db: 70})
var ob2=new IT(102, 'Gopaal', 21,{net:56, cloud: 76, db:76})
var ob3=new CS(103, 'Vijay', 22, {aws: 35, ml: 35, db: 35})
var ob4=new IT(104, 'Ajay', 25,{net:35, cloud: 44, db:76})
var ob5=new CS(105, 'Meena', 24, {aws: 56, ml: 76, db: 76})
var ob6=new IT(106, 'Reena', 22,{net:56, cloud: 60, db:76})
var ob7=new CS(107, 'Akash', 25, {aws: 56, ml: 76, db: 76})
var ob8=new IT(108, 'Pooja', 21,{net:40, cloud: 75, db:76})

var arr=[ob1, ob2, ob3, ob4, ob5, ob5, ob6, ob7, ob8]
function getPercentage(obj){
    var marks=obj.marks
    var data=Object.values(marks)
    var total=data.reduce((a,b)=>{
        return a+b;
    },0);
    var per=total/3;
    return per;
}
var num=69;
var arr2=arr.filter((ob)=>getPercentage(ob)>num)
console.log(arr2)