import express from "express";
import { engine } from "express-handlebars";
 
var app= express();
const port = process.env.PORT || 8082;
let m={
    items:[
        {
            id: 1,
            img: "https://rukminim1.flixcart.com/image/612/612/jn7rzww0/living-room-chair/x/4/q/na-pp-texas-supreme-brown-original-imaf9xkexyh2t2dq.jpeg?q=70", 
            name: "Chair",
            category: "Furniture",
            price: "2400",
            
          },
          {
            id: 2,
            img: "https://rukminim1.flixcart.com/image/312/312/keaaavk0/computer/x/m/y/lenovo-na-laptop-original-imafuzt8r5jqppfn.jpeg?q=70", 
            name: "Lenevo Laptop",
            category: "Electronics",
            price: "39900",
            details: {
              meow: "Meow Meow Meow",
              contact:"9064920473",
            },
          },
          {
            id: 3,
            img: "https://rukminim1.flixcart.com/image/660/792/kkoc70w0/shoe/8/3/e/6-rng2-blue-mcw-145-aircum-blue-original-imaf7x2ngxh2qmeh.jpeg?q=50", 
            name: "Shoes",
            category: "Fashion",
            price: "260",
            details: {
              meow: "Meow Meow Meow",
              contact:"8392035920",
            },
          },
    ],

};
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');

app.get('/',(req, res)=>{
    res.render('home',{data:m});
   
});
app.get('/',(req, res)=>{
    res.render('home',{items:p});
   
});

app.get('/', function(req, res){
    res.render('home');
});

app.get("/details/:id", (req, res) => {
    m.items.forEach(e => {
        if(e.id == req.params.id) {
            res.render("details", {data: e});
        }
    });
});
app.get("/cart/:id", (req, res) => {
  
          res.render("cart");
});
app.listen(port, () => console.log(`App Started! ${port}`));