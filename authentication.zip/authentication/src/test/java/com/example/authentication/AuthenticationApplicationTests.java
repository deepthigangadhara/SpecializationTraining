package com.example.authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
