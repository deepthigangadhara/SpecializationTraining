package Movie_Ticket;
public class movie{
    int total_tickets;
    int total_shows;
    public void bookTicket(int total_tickets){}
    public void RefillTicket(int total_shows){}

}