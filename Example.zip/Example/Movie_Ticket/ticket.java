package Movie_Ticket;

public class ticket {
    public static void main( String [] args){
        int n;
        int capacity;

    }
    
}
