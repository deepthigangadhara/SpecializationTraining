package accounts;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Account ac=new Account();
        GoldAccount ga=new GoldAccount();
        PlatinumAccount pa=new PlatinumAccount();
        Scanner scan = new Scanner(System.in);
        
        while(true){
            System.out.println("To withdraw amount from GoldAccount enter 1");
            System.out.println("To withdraw amount from PlatinumAccount enter 2");
            System.out.println("To print GoldAccount balance enter 3");
            System.out.println("To print PlatinumAccount balance enter 4");
            System.out.println("To Deposit Amount enter 5");
            System.out.println("To exit enter 6");
            System.out.println("Enter your choice::");
            
			int choice = scan.nextInt();
            switch(choice){
                case 1: System.out.println("Enter amount to withdraw: ");
                        int w=scan.nextInt();
                        ga.withdraw(w);
                        System.out.println("Total balance is: "+ga.balance_amount);
                break;
                case 2: pa.withdraw();
                break;
                case 3: ga.print();
                break;
                case 4: pa.print();
                break;
                case 5: System.out.println("Enter amount to deposit: ");
                        int a = scan.nextInt();
                        ac.deposit(a);
                        System.out.println("Total balance is: "+ac.balance_amount);
                break;
                case 6: System.out.println("Exiting the application");
                System.exit(0);
                default: System.out.println("Incorrect input!!! Please re-enter choice from our menu");
                }
            
        }
        
    }
    
}
