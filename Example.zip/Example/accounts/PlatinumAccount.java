package accounts;

public class PlatinumAccount extends Account{
    int creditlimit;
    public void withdraw(){}
    public void print(){}
    
}
