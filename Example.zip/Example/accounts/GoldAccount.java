package accounts;

public class GoldAccount extends Account{
    int creditLimit;
    @Override
    public int withdraw(int b) {
        
        return super.withdraw(b);
    }
    public void print(){}
    
}
