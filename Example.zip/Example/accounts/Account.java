package accounts;
public class Account{
    String owner;
    int balance_amount;
    public void init(){}
    public int deposit(int amount){
        balance_amount=balance_amount+amount;
        
        return balance_amount;
        
    }
    int blnc=balance_amount;
    public int withdraw(int b){
        balance_amount=blnc;
        return balance_amount;
    }
    public void print(){}


}