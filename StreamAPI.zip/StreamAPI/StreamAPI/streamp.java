package StreamAPI;
import java.util.*;
import java.util.stream.Collectors;
public class streamp{
    public static void main(String[] args) {
        //List<Integer> list= new ArrayList<Integer>();
        var list= new ArrayList<Integer>();
        list.add(10);
        list.add(12);
        list.add(3);
        list.stream().filter(e->(e%2==0)).collect(Collectors.toList()).forEach(System.out::println);
    }

}
