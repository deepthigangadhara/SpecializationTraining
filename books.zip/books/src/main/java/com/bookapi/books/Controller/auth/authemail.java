package com.bookapi.books.Controller.auth;

import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.bookapi.books.response;

import com.bookapi.books.Controller.DB.userRepo;
import com.bookapi.books.Controller.Models.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class authemail {
   /* @Autowired
    private JavaMailSender javaMailSender;
    
    //@GetMapping("/send")
    @PostMapping("/send/{email}")
    
    String sendEmail(@PathVariable String email){
        SimpleMailMessage msg=new SimpleMailMessage();
       /* msg.setTo("101deepthig@gmail.com");
        msg.setSubject("Testing from Spring Boot");
        msg.setText("Hello world \n Spring B[t Email");
        try{
            javaMailSender.send(msg);
            return "message sent";
        }
        catch(Exception e){
            return e.getMessage();
        }*
        msg.setTo(email);
        Random random=new Random();
        String n=String.format("%04d", random.nextInt(10000));
        msg.setSubject("Authenticate");
        msg.setText("Your code is: "+n);
        try{
            javaMailSender.send(msg);
            return n+"";
        }
        catch(Exception e){
            return e.getMessage();
        }
    }*/
    @Autowired
    JavaMailSender javaMailSender;
    @Autowired
    userRepo repo;
    
    @PostMapping("/register")
    
    public response register(@RequestBody user model){
        if(repo.count()>0){
        List<user> list=repo.findAll();

        for(user user:list){
            if(user.getEmail().equals(model.getEmail())){
                return new response(404, "User exists", model);
            }
            
        }}
        model.setUid(UUID.randomUUID().toString());
        SimpleMailMessage msg=new SimpleMailMessage();
      
        msg.setTo(model.getEmail());
        Random random=new Random();
        String n=String.format("%04d", random.nextInt(10000));
        msg.setSubject("Authenticate");
        msg.setText("Your code is: "+n);
        try{
            javaMailSender.send(msg);
            repo.insert(model);
            return new response(200, "Code sent Successfully", n);
        }
        catch(Exception e){
            return new response(404, e.getMessage(), null);
        }
    }
    @PostMapping("/login")
    
    public response login(@RequestBody user model){
        if(repo.count()>0){
        List<user> list=repo.findAll();

        for(user m:list){
            if(m.getEmail().equals(model.getEmail())&& m.getPassword().equals(model.getPassword())){
                return new response(200, "Logged in Successfully", model);
            }
            
        }}
        return new response(404, "No user found with this email", null);

    }
}
