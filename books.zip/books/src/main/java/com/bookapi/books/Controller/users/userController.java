package com.bookapi.books.Controller.users;

import com.bookapi.books.Controller.DB.userRepo;
import com.bookapi.books.Controller.Models.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class userController {
    @Autowired
    userRepo repo;
    @PostMapping("/addUser")
    public void addUser(@RequestBody user u){
         repo.insert(u);
    }
    
}
