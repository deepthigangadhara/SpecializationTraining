package com.bookapi.books.Controller.Models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class books {
    int id;
    String name;
    String author;
    int price;

    
}
