package com.bookapi.books.Controller.Books;

import java.util.List;

import com.bookapi.books.response;
import com.bookapi.books.Controller.DB.bookRepo;
import com.bookapi.books.Controller.Models.books;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
public class bookController {
    @Autowired
    bookRepo brepo;
    @PostMapping("/addbooks")
    public response addBook(@RequestBody books b){
        if(brepo.count()>0){
            List<books> list=brepo.findAll();
    
            for(books book:list){
                if(book.getName().equals(b.getName())){
                    return new response(404, "Book exists", b);
                }
                
            }
        }   
         
         brepo.insert(b);
         return new response(200, "Book added Successfully", b);
       
    }
    @GetMapping("/getbooks")
    public List<books> getBooks(){
        return brepo.findAll();
        
    }
    @GetMapping("/delete/{id}")
    public response deleteById(@PathVariable int id){
       
        brepo.deleteById(id);
        return new response(200, "Book deleted Successfully", null);
    }
    @PostMapping("/update")
    public response updateBook(@RequestBody books b){
        if(brepo.existsById(b.getId())){
            books book=brepo.findById(b.getId()).get();
            book.setName(b.getName());
            book.setAuthor(b.getAuthor());
            book.setPrice(b.getPrice());
            brepo.save(book);
            return new response(200, "Book updated Successfully", book);

        }
        return new response(404, "Book not found", null);
    }
}
