package com.bookapi.books.Controller.DB;



import com.bookapi.books.Controller.Models.user;

import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;
@Repository
public interface userRepo extends MongoRepository<user, String>{

   

}
