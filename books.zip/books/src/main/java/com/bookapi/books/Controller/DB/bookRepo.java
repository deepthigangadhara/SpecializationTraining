package com.bookapi.books.Controller.DB;

import java.util.Optional;

import com.bookapi.books.Controller.Models.books;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface bookRepo extends MongoRepository<books, String>{

    void deleteById(int id);

    Optional<books> findById(int id);

    boolean existsById(int id);
    
}
