import express from "express";
import { engine } from "express-handlebars";
 
var app= express();
const port = process.env.PORT || 8081;
let m={
    name:"meow",
    cat:"meow",
    people:[
        {
            id: 1,
            img: "https://png.pngtree.com/png-vector/20190114/ourlarge/pngtree-vector-avatar-icon-png-image_313572.jpg", 
            firstname: "Deepthi",
            lastname: "G",
            role: "Developer",
            details: {
              meow: "Meow Meow Meow",
              contact: "8088594831",
            },
          },
          {
            id: 2,
            img: "https://png.pngtree.com/png-vector/20190114/ourlarge/pngtree-vector-avatar-icon-png-image_313572.jpg", 
            firstname: "Chaithra",
            lastname: "D",
            role: "Developer",
            details: {
              meow: "Meow Meow Meow",
              contact:"9064920473",
            },
          },
          {
            id: 3,
            img: "https://png.pngtree.com/png-vector/20190114/ourlarge/pngtree-vector-avatar-icon-png-image_313572.jpg", 
            firstname: "Thripthi",
            lastname: "K",
            role: "Developer",
            details: {
              meow: "Meow Meow Meow",
              contact:"8392035920",
            },
          },
    ],

};

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');

app.get('/',(req, res)=>{
    res.render('home',{data:m});
   
});
app.get('/',(req, res)=>{
    res.render('home',{people:p});
   
});

app.get('/', function(req, res){
    res.render('home');
});

app.get("/details/:id", (req, res) => {
    m.people.forEach(e => {
        if(e.id == req.params.id) {
            res.render("details", {data: e});
        }
    });
});
app.listen(port, () => console.log(`App Started! ${port}`));